    根据log来看,这个问题主要在于当卡槽1的联通sim卡拔出重新插入移动sim卡的时候,在移动sim卡load完成之前已经有设置默认数据卡
的操作触发,这时候因为使用的是缓存的sim卡信息,故获取到的默认数据卡subid还是之前联通卡的subid,从而造成了这个问题.
修改主要涉及的文件有两个:
 
 1.frameworks/opt/telephony/src/java/com/android/internal/telephony/SubscriptionController.java

 2.frameworks/opt/telephony/src/java/com/android/internal/telephony/SubscriptionInfoUpdater.java
