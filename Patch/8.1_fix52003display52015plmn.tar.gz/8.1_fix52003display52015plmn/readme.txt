解决该问题的相关修改如下,请合入后验证.
1.vendor/sprd/platform/frameworks/opt/telephony/src/java/com/android/internal/telephony/OperatorNameHandler.java
   对应patch文件为 vendor_framework_opt.diff

2.vendor/sprd/platform/frameworks/base/ex-interface/telephony/java/android/telephony/CarrierConfigManagerEx.java
   对应patch文件为 vendor_framework_base.diff

3.vendor/sprd/platform/packages/apps/CarrierConfig/assets/carrier_config_52001.xml
  vendor/sprd/platform/packages/apps/CarrierConfig/assets/carrier_config_52003.xml
    对应patch文件为 vendor_carrierconfig.diff
